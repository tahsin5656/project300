-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 17, 2024 at 08:43 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `course_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `batch_51`
--

CREATE TABLE `batch_51` (
  `COURSE_NAME` varchar(255) DEFAULT NULL,
  `COURSE_CODE` varchar(100) DEFAULT NULL,
  `COURSE_CREDIT` varchar(255) DEFAULT NULL,
  `FACULTY_NAME` varchar(255) DEFAULT NULL,
  `CLASSROOM_CODE` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batch_51`
--

INSERT INTO `batch_51` (`COURSE_NAME`, `COURSE_CODE`, `COURSE_CREDIT`, `FACULTY_NAME`, `CLASSROOM_CODE`) VALUES
('Computer Graphics & Image Processing', 'CSE 401', '3', 'Abdul Wadud Shakib', 'wnreudm'),
('Computer Graphics & Image Processing Lab', 'CSE 402', '1.5', 'Abdul Wadud Shakib', 'wnreudm'),
('Digital Signal Processing', 'CSE 441', '3', 'Ahmed Istiakur Rahman', 'arpqaxp'),
('Digital Signal Processing Lab', 'CSE 442', '1.5', 'Ahmed Istiakur Rahman', 'arpqaxp'),
('Technical Writing and Presentation', 'CSE 429', '2', '', ''),
('Final Year Project/Thesis/Internship', 'CSE 435', '2', '', ''),
('Final Year Project/Thesis/Internship', 'CSE 436', '4', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `batch_52`
--

CREATE TABLE `batch_52` (
  `COURSE_NAME` varchar(255) DEFAULT NULL,
  `COURSE_CODE` varchar(255) DEFAULT NULL,
  `COURSE_CREDIT` varchar(255) DEFAULT NULL,
  `FACULTY_NAME` varchar(255) DEFAULT NULL,
  `CLASSROOM_CODE` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batch_52`
--

INSERT INTO `batch_52` (`COURSE_NAME`, `COURSE_CODE`, `COURSE_CREDIT`, `FACULTY_NAME`, `CLASSROOM_CODE`) VALUES
('Artificial Intelligence', 'CSE 421', '3', 'Archi Arani Basak', 'zr7uugk'),
('Artificial Intelligence lab', 'CSE 422', '1.5', 'Archi Arani Basak', 'zr7uugk'),
('Digital Signal Processing', 'CSE 441', '3', 'Ahmed Istiakur Rahman', 'arpqaxp'),
('Digital Signal Processing Lab', 'CSE 442', '1.5', 'Ahmed Istiakur Rahman', 'arpqaxp'),
('Technical Writing and Presentation', 'CSE 429', '2', '', ''),
('Bioinformatics Computing', 'CSE 469', '3', 'Tanjina Ahmed Mumu', 'klbeoen'),
('Bioinformatics Computing Lab', 'CSE 470', '1.5', 'Tanjina Ahmed Mumu', 'klbeoen');

-- --------------------------------------------------------

--
-- Table structure for table `batch_53`
--

CREATE TABLE `batch_53` (
  `COURSE_NAME` varchar(255) DEFAULT NULL,
  `COURSE_CODE` varchar(255) DEFAULT NULL,
  `COURSE_CREDIT` varchar(255) DEFAULT NULL,
  `FACULTY_NAME` varchar(255) DEFAULT NULL,
  `CLASSROOM_CODE` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batch_53`
--

INSERT INTO `batch_53` (`COURSE_NAME`, `COURSE_CODE`, `COURSE_CREDIT`, `FACULTY_NAME`, `CLASSROOM_CODE`) VALUES
('Artificial Intelligence', 'CSE 421', '3', 'Archi Arani Basak', 'zr7uugk'),
('Artificial Intelligence lab', 'CSE 422', '1.5', 'Archi Arani Basak', 'zr7uugk'),
('Operating System', 'CSE 321', '3', 'Nabila Zannat Rifa', 'ibyfna'),
('Operating System Lab', 'CSE 322', '1.5', 'Nabila Zannat Rifa', 'ribyfna'),
('Digital Signal Processing', 'CSE 441', '3', 'Ahmed Istiakur Rahman', 'arpqaxp'),
('Digital Signal Processing Lab', 'CSE 442', '1.5', 'Ahmed Istiakur Rahman', 'arpqaxp'),
('Engineering Ethics and Cyber Law', 'GED 119', '2', 'Syeda Nazmur Siha', 'r7octwe'),
('Technical Writing and Presentation', 'CSE 429', '2', '', ''),
('Bioinformatics Computing', 'CSE 469', '3', 'Tanjina Ahmed Mumu', 'klbeoen'),
('Bioinformatics Computing Lab', 'CSE 470', '1.5', 'Tanjina Ahmed Mumu', 'klbeoen');

-- --------------------------------------------------------

--
-- Table structure for table `batch_54`
--

CREATE TABLE `batch_54` (
  `COURSE_NAME` varchar(255) DEFAULT NULL,
  `COURSE_CODE` varchar(255) DEFAULT NULL,
  `COURSE_CREDIT` varchar(255) DEFAULT NULL,
  `FACULTY_NAME` varchar(255) DEFAULT NULL,
  `CLASSROOM_CODE` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batch_54`
--

INSERT INTO `batch_54` (`COURSE_NAME`, `COURSE_CODE`, `COURSE_CREDIT`, `FACULTY_NAME`, `CLASSROOM_CODE`) VALUES
('Operating System', 'CSE 321', '3', 'Nabila Zannat Rifa', 'ribyfna'),
('Operating System Lab', 'CSE 322', '1.5', 'Nabila Zannat Rifa', 'ribyfna'),
('Digital Signal Processing', 'CSE 441', '3', 'Ahmed Istiakur Rahman', 'arpqaxp'),
('Digital Signal Processing Lab', 'CSE 442', '1.5', 'Ahmed Istiakur Rahman', 'arpqaxp'),
('Engineering Ethics and Cyber Law', 'GED 119', '2', 'Syeda Nazmur Siha', 'r7octwe'),
('Technical Writing and Presentation', 'CSE 429', '2', '', ''),
('History of Emergence of Bangladesh', 'GED 202', '3', 'Salma Akther', 'ydjnyph'),
('Bioinformatics Computing', 'CSE 469', '3', 'Tanjina Ahmed Mumu', 'klbeoen'),
('Bioinformatics Computing Lab', 'CSE 470', '1.5', 'Tanjina Ahmed Mumu', 'klbeoen');

-- --------------------------------------------------------

--
-- Table structure for table `batch_55`
--

CREATE TABLE `batch_55` (
  `COURSE_NAME` varchar(255) DEFAULT NULL,
  `COURSE_CODE` varchar(255) DEFAULT NULL,
  `COURSE_CREDIT` varchar(255) DEFAULT NULL,
  `FACULTY_NAME` varchar(255) DEFAULT NULL,
  `CLASSROOM_CODE` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batch_55`
--

INSERT INTO `batch_55` (`COURSE_NAME`, `COURSE_CODE`, `COURSE_CREDIT`, `FACULTY_NAME`, `CLASSROOM_CODE`) VALUES
('Engineering Ethics and Cyber Law', 'GED 119', '2', 'Syeda Nazmur Siha', 'r7octwe'),
('History of Emergence of Bangladesh', 'GED 202', '3', 'Salma Akther', 'ydjnyph'),
('Computer Networks', 'CSE 311', '3', 'Archi Arani Basak', 'dxqf6uh'),
('Computer Networks Lab', 'CSE 312', '1.5', 'Archi Arani Basak', 'dxqf6uh'),
('Operating System', 'CSE 321', '3', 'Nabila Zannat Rifa', 'ribyfna'),
('Operating System Lab', 'CSE 322', '1.5', 'Nabila Zannat Rifa', 'ribyfna'),
('Business Communication', 'GED 431', '3', 'Chowdhury Mujaddid Ahmed', 'jylmoeo'),
('Software Engineering & Design Pattern', 'CSE 417', '3', 'Md. Mushtaq Shahriyar Rafee', 'v3a4d6l'),
('Software Engineering & Design Pattern Lab', 'CSE 418', '1.5', 'Md. Mushtaq Shahriyar Rafee', 'v3a4d6l');

-- --------------------------------------------------------

--
-- Table structure for table `batch_56`
--

CREATE TABLE `batch_56` (
  `COURSE_NAME` varchar(255) DEFAULT NULL,
  `COURSE_CODE` varchar(255) DEFAULT NULL,
  `COURSE_CREDIT` varchar(255) DEFAULT NULL,
  `FACULTY_NAME` varchar(255) DEFAULT NULL,
  `CLASSROOM_CODE` varchar(255) DEFAULT NULL,
  `SECTION` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batch_56`
--

INSERT INTO `batch_56` (`COURSE_NAME`, `COURSE_CODE`, `COURSE_CREDIT`, `FACULTY_NAME`, `CLASSROOM_CODE`, `SECTION`) VALUES
('Web Programming Lab', 'CSE 323', '3', 'Golam Mostafa Naeem', '', 'A'),
('Web Programming Lab', 'CSE 323', '3', 'Nasif Istiak Remon', 'webdhwq', 'B'),
('Web Programming Lab', 'CSE 323', '3', 'Nasif Istiak Remon', 'zdlot42', 'C & D'),
('Project', 'CSE 300', '1.5', 'Golam Mostofa Naeem', 'v5xhc7g', 'A'),
('Project', 'CSE 300', '1.5', 'Nasif Istiak Remon', 'webdhwq', 'B'),
('Project', 'CSE 300', '1.5', 'Nasif Istiak Remon', 'hiwglq7', 'C & D'),
('Communication Engineering', 'CSE 215', '3', 'Md. Mahfujul Hasan', 'lpy73fh', 'A,B,C & D'),
('Microprocessor & Interfacing', 'CSE 237', '3', 'Mayami Das Purkayastha Purba', 'gdfugbo', 'A'),
('Microprocessor & Interfacing', 'CSE 237', '3', 'Mayami Das Purkayastha Purba', 'jjqfztz', 'B'),
('Microprocessor & Interfacing', 'CSE 237', '3', 'Md. Fahmidur Rahman Sakib', 'lofqqwo', 'C & D'),
('Microprocessor & Interfacing Lab', 'CSE 238', '1.5', 'Mayami Das Purkayastha Purba', 'gdfugbo', 'A'),
('Microprocessor & Interfacing Lab', 'CSE 238', '1.5', 'Mayami Das Purkayastha Purba', 'jjqfztz', 'B'),
('Microprocessor & Interfacing Lab', 'CSE 238', '1.5', 'Md. Fahmidur Rahman Sakib', 'lofqqwo', 'C & D'),
('Numerical Methods', 'MAT 235', '3', 'Md. Fahmidur Rahman Sakib', 'xp3yg76', 'A & B'),
('Numerical Methods', 'MAT 235', '3', 'Md. Fahmidur Rahman Sakib', 'bozq7gh', 'C & D'),
('Industrial Management & Financial Accounting', 'GED 215', '3', 'Dr. Urmee ghose', '', 'A,B,C & D'),
('Computer Organization & Architecture', 'CSE 213', '3', 'Samia Rahman Rima', '', 'A,B,C & D');

-- --------------------------------------------------------

--
-- Table structure for table `batch_57`
--

CREATE TABLE `batch_57` (
  `COURSE_NAME` varchar(255) DEFAULT NULL,
  `COURSE_CODE` varchar(255) DEFAULT NULL,
  `COURSE_CREDIT` varchar(255) DEFAULT NULL,
  `FACULTY_NAME` varchar(255) DEFAULT NULL,
  `CLASSROOM_CODE` varchar(255) DEFAULT NULL,
  `SECTION` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batch_57`
--

INSERT INTO `batch_57` (`COURSE_NAME`, `COURSE_CODE`, `COURSE_CREDIT`, `FACULTY_NAME`, `CLASSROOM_CODE`, `SECTION`) VALUES
('Digital Logic Design', 'CSE 211', '3', 'Sadman Sakib', 'sfuidyl', 'A,B,F & G'),
('Digital Logic Design Lab', 'CSE 212', '1.5', 'Sadman Sakib', 'sfuidyl', 'A,B,F & G'),
('Digital Logic Design', 'CSE 211', '3', 'Md Fardin Ahasan Maraz', 'xw6g5aa', 'C & E'),
('Digital Logic Design Lab', 'CSE 212', '1.5', 'Md Fardin Ahasan Maraz', 'xw6g5aa', 'C & E'),
('Digital Logic Design', 'CSE 211', '3', 'Md. Anwarul Kawsar\r\n', 'xp3qdri', 'D'),
('Digital Logic Design Lab', 'CSE 212', '1.5', 'Md. Anwarul Kawsar\r\n', 'xp3qdri', 'D'),
('Database Management System', 'CSE 223', '3', 'Nowshin Sharmin', '7k7mt26', 'A & B'),
('Database Management System Lab', 'CSE 224', '1.5', 'Nowshin Sharmin', '7k7mt26', 'A & B'),
('Database Management System', 'CSE 223', '3', 'Khudeja Khanom Anwara\r\n', 'abb3rju', 'C & E'),
('Database Management System Lab', 'CSE 224', '1.5', 'Khudeja Khanom Anwara', 'abb3rju', 'C & E'),
('Database Management System', 'CSE 223', '3', 'Tajbin Jahan', 'nuy7v4j\r\n', 'D'),
('Database Management System Lab', 'CSE 224', '1.5', 'Tajbin Jahan', 'nuy7v4j', 'D'),
('Database Management System', 'CSE 223', '3', 'Abdul Wadud Shakib\r\n', 'tkzfc6j', 'F & G'),
('Database Management System Lab', 'CSE 224', '1.5', 'Abdul Wadud Shakib\r\n', 'tkzfc6j', 'F & G'),
('Geometry & Vector Analysis', 'MAT 216', '3', '', '', 'A,B,C,D,E,F & G'),
('Business Communication', 'GED 431', '3', 'Chowdhury Mujaddid Ahmed', '2okwmoy', 'A & B'),
('Business Communication', 'GED 431', '3', 'Chowdhury Mujaddid Ahmed', 'yl6ec7b', 'C & E'),
('Business Communication', 'GED 431', '3', 'Chowdhury Mujaddid Ahmed', '4pfkwaf', 'D,F & G'),
('Competitive Programming', 'CSE 200', '1.5', '', '', 'A & B'),
('Competitive Programming', 'CSE 200', '1.5', 'Md. Mushtaq Shahriyar Rafee', 'sytiekp', 'C & E'),
('Competitive Programming', 'CSE 200', '1.5', '', '', 'D'),
('Competitive Programming', 'CSE 200', '1.5', 'Abu Jafar Md Jakaria', 'yr5avxu', 'F & G'),
('Theory of Computation', 'CSE 327', '3', 'Khudeja Khanom Anwara', '3ry6m3i', 'A & B'),
('Theory of Computation', 'CSE 327', '3', 'Khudeja Khanom Anwara', 'jgwwc4p', 'C & E'),
('Theory of Computation', 'CSE 327', '3', 'Golam Mostofa Naeem', '7736wdm', 'D'),
('Theory of Computation', 'CSE 327', '3', 'Golam Mostofa Naeem', 'unnrkch', 'F & G');

-- --------------------------------------------------------

--
-- Table structure for table `batch_58`
--

CREATE TABLE `batch_58` (
  `COURSE_NAME` varchar(255) DEFAULT NULL,
  `COURSE_CODE` varchar(255) DEFAULT NULL,
  `COURSE_CREDIT` varchar(255) DEFAULT NULL,
  `FACULTY_NAME` varchar(255) DEFAULT NULL,
  `CLASSROOM_CODE` varchar(255) DEFAULT NULL,
  `SECTION` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batch_58`
--

INSERT INTO `batch_58` (`COURSE_NAME`, `COURSE_CODE`, `COURSE_CREDIT`, `FACULTY_NAME`, `CLASSROOM_CODE`, `SECTION`) VALUES
('Basic Electronics Engineering', 'CSE 131', '3', 'Md. Anwarul Kawsar', 'kwwgci5', 'A'),
('Basic Electronics Engineering Lab', 'CSE 132', '1.5', 'Md. Anwarul Kawsar', 'kwwgci5', 'A'),
('Basic Electronics Engineering', 'CSE 131', '3', 'Md Hasanur Rahman Sohag\r\n', '4vzv7dq', 'B'),
('Basic Electronics Engineering Lab', 'CSE 132', '1.5', 'Md Hasanur Rahman Sohag', '4vzv7dq', 'B'),
('Basic Electronics Engineering', 'CSE 131', '3', 'Arpita Mazumder\r\n', 'w3ymbk2', 'C'),
('Basic Electronics Engineering Lab', 'CSE 132', '1.5', 'Arpita Mazumder\r\n', 'w3ymbk2', 'C'),
('Basic Electronics Engineering', 'CSE 131', '3', 'Ahmed Afif Rafsan\r\n', 'z4ohclp', 'D'),
('Basic Electronics Engineering Lab', 'CSE 132', '1.5', 'Ahmed Afif Rafsan', 'ptrvk4m', 'D'),
('Basic Electronics Engineering', 'CSE 131', '3', 'Zahidul salman\r\n', 'gpfzzgn', 'E'),
('Basic Electronics Engineering Lab', 'CSE 132', '1.5', 'Zahidul salman\r\n', 'gpfzzgn', 'E'),
('Basic Electronics Engineering', 'CSE 131', '3', 'Arpita Mazumder\r\n', '6v6bmi2', 'F'),
('Basic Electronics Engineering Lab', 'CSE 132', '1.5', 'Arpita Mazumder\r\n', '6v6bmi2', 'F'),
('Basic Electronics Engineering', 'CSE 131', '3', 'Ahmed Afif Rafsan\r\n', 'nx5tpxg', 'G & H'),
('Basic Electronics Engineering Lab', 'CSE 132', '1.5', 'Ahmed Afif Rafsan', 'nx5tpxg', 'G & H'),
('Basic Electronics Engineering', 'CSE 131', '3', 'Mahim Ahmed\r\n', 'kcx4sta', 'I'),
('Basic Electronics Engineering Lab', 'CSE 132', '1.5', 'Mahim Ahmed\r\n', 'kcx4sta', 'I'),
('Data Structure', 'CSE 133', '3', 'Iftekhar Hussain', '432mrs3\r\n', 'A'),
('Data Structure Lab', 'CSE 134', '1.5', 'Iftekhar Hussain', '432mrs3\r\n', 'A'),
('Data Structure', 'CSE 133', '3', '', '', 'B,C,E & F'),
('Data Structure Lab', 'CSE 134', '1.5', '', '', 'B,C,E & F'),
('Data Structure', 'CSE 133', '3', 'Nasif Istiak Remon\r\n', 'pc7nepo', 'D'),
('Data Structure Lab', 'CSE 134', '1.5', 'Nasif Istiak Remon\r\n', 'pc7nepo', 'D'),
('Data Structure', 'CSE 133', '3', 'Bushra Azmat Hussain', 'jfjysje', ' G & H'),
('Data Structure Lab', 'CSE 134', '1.5', 'Bushra Azmat Hussain', 'jfjysje', 'G & H'),
('Data Structure', 'CSE 133', '3', 'Bushra Azmat Hussain\r\n', 'c3v7kod', 'I'),
('Data Structure Lab', 'CSE 134', '1.5', 'Bushra Azmat Hussain\r\n', 'c3v7kod', 'I'),
('Principles of Economics & Entrepreneurship Development', 'GED 213', '3', '', '', 'A,B,C,D,E,F,G,H & I'),
('Basic Statistics & Probability', 'STA 215', '3', 'Muhammad Muzammil', 'rv74vou', 'A & B'),
('Basic Statistics & Probability', 'STA 215', '3', 'Muhammad Muzammil', 'h7cgsq4', 'C & D'),
('Basic Statistics & Probability', 'STA 215', '3', 'Muhammad Muzammil', 'yszxyht', 'E,G & H'),
('Basic Statistics & Probability', 'STA 215', '3', 'Muhammad Muzammil', 'hdmw4f5', 'F & I'),
('Matrices, Complex Variable & Fourier Analysis', 'MAT 135', '3', '', '', 'A,B & C'),
('Matrices, Complex Variable & Fourier Analysis', 'MAT 135', '3', 'Ruhul Amin(RAR)', 'ucopij5', 'D'),
('Matrices, Complex Variable & Fourier Analysis', 'MAT 135', '3', 'Ruhul Amin(RAR)', 'gule2zc', 'E'),
('Matrices, Complex Variable & Fourier Analysis', 'MAT 135', '3', 'Ahmed Istiakur Rahman', '6mermqp', 'F'),
('Matrices, Complex Variable & Fourier Analysis', 'MAT 135', '3', 'Syed Imam Mahdi', '4d3o54p', 'G & H'),
('Matrices, Complex Variable & Fourier Analysis', 'MAT 135', '3', 'Syed Imam Mahdi', 'aevr4nb', 'I');

-- --------------------------------------------------------

--
-- Table structure for table `batch_59`
--

CREATE TABLE `batch_59` (
  `COURSE_NAME` varchar(255) DEFAULT NULL,
  `COURSE_CODE` varchar(255) DEFAULT NULL,
  `COURSE_CREDIT` varchar(255) DEFAULT NULL,
  `FACULTY_NAME` varchar(255) DEFAULT NULL,
  `CLASSROOM_CODE` varchar(255) DEFAULT NULL,
  `SECTION` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batch_59`
--

INSERT INTO `batch_59` (`COURSE_NAME`, `COURSE_CODE`, `COURSE_CREDIT`, `FACULTY_NAME`, `CLASSROOM_CODE`, `SECTION`) VALUES
('Structured Programming', 'CSE 121', '3', 'Tanjina Ahmed Mumu\r\n', 'sy3olcr', 'A'),
('Structured Programming Lab', 'CSE 122', '1.5', 'Tanjina Ahmed Mumu\r\n', 'sy3olcr', 'A'),
('Structured Programming', 'CSE 121', '3', 'Mayami Das Purkayastha Purba\r\n', 'tf6v4he', 'B'),
('Structured Programming Lab', 'CSE 122', '1.5', 'Mayami Das Purkayastha Purba', 'tf6v4he', 'B'),
('Structured Programming', 'CSE 121', '3', 'Khudeja Khanom Anwara\r\n', 'yxykdbp', 'C'),
('Structured Programming Lab', 'CSE 122', '1.5', 'Khudeja Khanom Anwara\r\n', 'yxykdbp', 'C'),
('Structured Programming', 'CSE 121', '3', 'Nowshin Sharmin\r\n', '6qjvo4p', 'D'),
('Structured Programming Lab', 'CSE 122', '1.5', 'Nowshin Sharmin\r\n', '6qjvo4p', 'D'),
('Structured Programming', 'CSE 121', '3', 'Bushra Azmat Hussain\r\n', 'ewvtsgg', 'E'),
('Structured Programming Lab', 'CSE 122', '1.5', 'Bushra Azmat Hussain\r\n', 'ewvtsgg', 'E'),
('Structured Programming', 'CSE 121', '3', 'Abu Jafar Md Jakaria\r\n', '5cng4zc', 'F'),
('Structured Programming Lab', 'CSE 122', '1.5', 'Abu Jafar Md Jakaria\r\n', '5cng4zc', 'F'),
('Structured Programming', 'CSE 121', '3', 'Tanjina Ahmed Mumu\r\n', 'okjoo2l', 'G'),
('Structured Programming Lab', 'CSE 122', '1.5', 'Tanjina Ahmed Mumu\r\n', 'okjoo2l', 'G'),
('Structured Programming', 'CSE 121', '3', 'Rishad Amin Pulok\r\n', 'no33ep6', 'H'),
('Structured Programming Lab', 'CSE 122', '1.5', 'Rishad Amin Pulok\r\n', 'no33ep6', 'H'),
('Structured Programming', 'CSE 121', '3', 'Rishad Amin Pulok\r\n', 'iefdyj2', 'I & J'),
('Structured Programming Lab', 'CSE 122', '1.5', 'Rishad Amin Pulok\r\n', 'iefdyj2', 'I & J'),
('Basic Electrical Engineering', 'CSE 123', '3', '', '', 'A & B'),
('Basic Electrical Engineering Lab', 'CSE 124', '1.5', '', '', 'A & B'),
('Basic Electrical Engineering', 'CSE 123', '3', 'Ahnaf Daiyan', '6yg6cc3', 'C'),
('Basic Electrical Engineering Lab', 'CSE 124', '3', 'Ahnaf Daiyan', '6yg6cc3', 'C'),
('Basic Electrical Engineering', 'CSE 123', '3', 'Ahnaf Daiyan', 'ynmjnv7', 'D'),
('Basic Electrical Engineering Lab', 'CSE 124', '3', 'Ahnaf Daiyan', 'ynmjnv7', 'D'),
('Basic Electrical Engineering', 'CSE 123', '3', 'Ahmed Istiakur Rahman', 'u3a74eg', 'E'),
('Basic Electrical Engineering Lab', 'CSE 124', '1.5', 'Ahmed Istiakur Rahman', 'u3a74eg', 'E'),
('Basic Electrical Engineering', 'CSE 123', '3', 'Ahnaf Daiyan', 'z4wgopa', 'F'),
('Basic Electrical Engineering Lab', 'CSE 124', '1.5', 'Ahnaf Daiyan', 'z4wgopa', 'F'),
('Basic Electrical Engineering', 'CSE 123', '3', 'Moshiur Ahmed', 'g4ygolp', 'G'),
('Basic Electrical Engineering Lab', 'CSE 124', '1.5', 'Moshiur Ahmed', 'g4ygolp', 'G'),
('Basic Electrical Engineering', 'CSE 123', '3', 'Moshiur Ahmed', 'h6xvkrs', 'H'),
('Basic Electrical Engineering Lab', 'CSE 124', '1.5', 'Moshiur Ahmed', 'h6xvkrs', 'H'),
('Basic Electrical Engineering', 'CSE 123', '3', 'Moshiur Ahmed', '5eqhqsd', 'I & J'),
('Basic Electrical Engineering Lab', 'CSE 124', '1.5', 'Moshiur Ahmed', '5eqhqsd', 'I & J'),
('Physics II', 'PHY 123', '3', 'Zahidul salman', '6lovs3t', 'A & B'),
('Physics II', 'PHY 123', '3', 'Safwan Uddin Ahmed\r\n', 'gqqpr6w', 'C & D'),
('Physics II', 'PHY 123', '3', 'Safwan Uddin Ahmed\r\n', '2fgwl7v', 'E & F'),
('Physics II', 'PHY 123', '3', 'Ahmed Istiakur Rahman', '7gsk6jh', 'G'),
('Physics II', 'PHY 123', '3', 'Zahidul salman', '5plhykl', 'H'),
('Physics II', 'PHY 123', '3', 'Mahim Ahmed', 'ct4tuct', 'I & J'),
('Differential Equation & Laplace Transform', 'MAT 123', '3', 'Syed Imam Mahdi', 'ypwnsks', 'A'),
('Differential Equation & Laplace Transform', 'MAT 123', '3', 'Syed Imam Mahdi', 'qh6cvkr', 'B'),
('Differential Equation & Laplace Transform', 'MAT 123', '3', 'Syed Imam Mahdi', 'pbk27n2', 'C'),
('Differential Equation & Laplace Transform', 'MAT 123', '3', 'Nazrul Islam', 'yqmu2dz', 'D'),
('Differential Equation & Laplace Transform', 'MAT 123', '3', 'Nazrul Islam', 'sn25ukd', 'E'),
('Differential Equation & Laplace Transform', 'MAT 123', '3', 'Ruma Das', '6evhxud', 'F'),
('Differential Equation & Laplace Transform', 'MAT 123', '3', 'Ruhul Amin(RAR)', 'xkmcpyn', 'G'),
('Differential Equation & Laplace Transform', 'MAT 123', '3', 'Ruhul Amin(RAR)', 'o5lm3fz', 'H'),
('Differential Equation & Laplace Transform', 'MAT 123', '3', 'Ruhul Amin(RAR)', 'goz2yir', 'I & J'),
('English II', 'ENG 115', '3', '', '', 'A,B,C,D,E,F,G,H,I & J'),
('Engineering Ethics and Cyber Law', 'GED 119', '3', '', '', 'A,B,C,D,E & F'),
('Engineering Ethics and Cyber Law', 'GED 119', '3', 'Syeda Nazmur Siha', '2jlnnes', 'G,H,I & J');

-- --------------------------------------------------------

--
-- Table structure for table `batch_60`
--

CREATE TABLE `batch_60` (
  `COURSE_NAME` varchar(255) DEFAULT NULL,
  `COURSE_CODE` varchar(255) DEFAULT NULL,
  `COURSE_CREDIT` varchar(255) DEFAULT NULL,
  `FACULTY_NAME` varchar(255) DEFAULT NULL,
  `CLASSROOM_CODE` varchar(255) DEFAULT NULL,
  `SECTION` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batch_60`
--

INSERT INTO `batch_60` (`COURSE_NAME`, `COURSE_CODE`, `COURSE_CREDIT`, `FACULTY_NAME`, `CLASSROOM_CODE`, `SECTION`) VALUES
('Discrete Mathematics', 'CSE 125', '3', 'Shrabanti Chowdhury', '2qhdzlf', 'A'),
('Discrete Mathematics', 'CSE 125', '3', 'Tajbin Jahan', 'jf23cko', 'B'),
('Discrete Mathematics', 'CSE 125', '3', 'Golam Mostofa Naeem', 'q6b2bbe', 'C'),
('Discrete Mathematics', 'CSE 125', '3', 'Shrabanti Chowdhury', 'y3awodv', 'D'),
('Discrete Mathematics', 'CSE 125', '3', 'Samia Rahman Rima', 'du27c3v', 'E'),
('Discrete Mathematics', 'CSE 125', '3', 'Shrabanti Chowdhury', '4ye7avf', 'F'),
('Discrete Mathematics', 'CSE 125', '3', 'Samia Rahman Rima', '', 'G'),
('Discrete Mathematics', 'CSE 125', '3', '', '', 'H'),
('Bangladesh Studies', 'GED 201', '3', '', '', 'A,B,C,D,E,F,G & H'),
('History of Emergence of Bangladesh', 'GED 202', '3', 'Salma Akther', 'phtunaw', 'A & B'),
('History of Emergence of Bangladesh', 'GED 202', '3', 'Salma Akther', '3idsdt2', 'C & D'),
('History of Emergence of Bangladesh', 'GED 202', '3', 'Salma Akther', 'gm7j6jc', 'E & F'),
('History of Emergence of Bangladesh', 'GED 202', '3', '', '', 'G & H'),
('English I', 'ENG 114', '3', 'Farhana Khanom Joly', 'gvkkicp', 'A & B'),
('English I', 'ENG 114', '3', '', '', 'C,D,E,F,G & H'),
('Physics I', 'PHY 111', '3', 'Ruma Das', 'vnqnhjq', 'A & B'),
('Physics I', 'PHY 111', '3', 'Ruma Das', 'tfpmyyc', 'C & D'),
('Physics I', 'PHY 111', '3', 'Ruma Das', 'u6x2wmm', 'E & F'),
('Physics I', 'PHY 111', '3', '', '', 'G & H'),
('Differential & Integral Calculus', 'MAT 112', '3', '', '', 'A & B'),
('Differential & Integral Calculus', 'MAT 112', '3', '', '', 'C & D'),
('Differential & Integral Calculus', 'MAT 112', '3', 'Tajbin Jahan', 'ijva64h', 'E'),
('Differential & Integral Calculus', 'MAT 112', '3', 'Samia Rahman Rima', '556jy2v', 'F');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
